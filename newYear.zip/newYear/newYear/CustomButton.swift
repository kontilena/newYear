//
//  CustomButton.swift
//  newYear
//
//  Created by Контиевская Елена Юрьевна on 20/12/2022.
//

import UIKit

@IBDesignable
class CustomButton: UIButton {
    @IBInspectable var cornerRadius: CGFloat = 0.0 {
        didSet {self.layer.cornerRadius = cornerRadius}
    }
}


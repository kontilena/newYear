//
//  ViewController.swift
//  newYear
//
//  Created by Контиевская Елена Юрьевна on 20/12/2022.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

